#!/bin/bash
while true; do
	read -p "Введите имя файла (или 'закрыть скрипт' для выхода): " filename
	if [[ $filename == "закрыть скрипт" ]]; then
		echo "Скрипт завершен."
		exit 0
	fi
	if [[ ! -e $filename ]]; then
		echo "Ошибка: файл не существует."
	else
		echo "Информация о файле $filename:"
		echo "Имя файла: $(basename $filename)"
		echo "Тип файла: $(file -b $filename)"
		echo "Размер файла: $(du -h $filename | awk '{print $1}')"
		echo "Владелец файла: $(stat -c %U $filename)"
		echo "Права доступа: $(stat -c %a $filename)"
		echo "Дата создания файла: $(stat -c %x $filename)"
	fi
	echo
done

